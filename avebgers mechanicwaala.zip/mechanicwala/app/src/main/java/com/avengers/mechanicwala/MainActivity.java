package com.avengers.mechanicwala;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.homepage);
        Button userButton=(Button)findViewById(R.id.mechanicButton);
        userButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              //  Toast.makeText(MainActivity.this,"clicking",Toast.LENGTH_SHORT).show();

                Intent intent=new Intent(MainActivity.this,MechanicLogin.class);
                startActivity(intent);
            }
        });
        Button mechanicLogin=findViewById(R.id.userButton);
        mechanicLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                   Intent intent=new Intent(MainActivity.this,UserLogin.class);//need to modify to userlogin
                  startActivity(intent);
            }
        });
    }
}
