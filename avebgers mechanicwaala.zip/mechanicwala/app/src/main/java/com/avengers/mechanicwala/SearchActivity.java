
package com.avengers.mechanicwala;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.avengers.mechanicwala.R;

public class SearchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_search);
    }
}
