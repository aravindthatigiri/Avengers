package com.avengers.mechanicwala.model;

import android.location.Location;

import java.io.Serializable;

public class UserModel implements Serializable {
    String name;
    String location;
    String phno;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getPhno() {
        return phno;
    }

    public void setPhno(String phno) {
        this.phno = phno;
    }
}
