package com.avengers.mechanicwala;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ListitemActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listitem);
    }
}
