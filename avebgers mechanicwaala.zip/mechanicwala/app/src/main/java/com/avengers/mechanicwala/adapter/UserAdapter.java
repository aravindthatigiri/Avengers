package com.avengers.mechanicwala.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.avengers.mechanicwala.ContactMechanicActivity;
import com.avengers.mechanicwala.ContactUserActivity;
import com.avengers.mechanicwala.R;
import com.avengers.mechanicwala.model.MechanicModel;
import com.avengers.mechanicwala.model.UserModel;
import com.avengers.mechanicwala.model.UserRequest;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.annotations.NonNull;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.MyHolder> {
    @NonNull
    private ArrayList<String> listS;
    List<UserRequest> list;
    Context context;
    int minteger = 0;
    MechanicAdapter.MyHolder holder;
    String string_i_need;

    public UserAdapter(List<UserRequest> list, Context context, String string_i_need) {
        this.list = list;
        this.context = context;
        this.string_i_need=string_i_need;
    }

    public UserAdapter() {

    }

    @Override
    public UserAdapter.MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.user_item, parent, false);
        UserAdapter.MyHolder myHoder = new UserAdapter.MyHolder(view);
        StrictMode.ThreadPolicy st = new StrictMode.ThreadPolicy.Builder().build();
        StrictMode.setThreadPolicy(st);

        return myHoder;
    }

    @Override
    public void onBindViewHolder(final UserAdapter.MyHolder holder, final int position) {
        final UserRequest mylist = list.get(position);


        holder.textViewName.setText("Name: "+mylist.getUserName());
        holder.textViewPhno.setText("Phno: "+mylist.getUserPhno());
        holder.textViewDate.setText("Date: "+mylist.getDate());

       // final UserModel mod=new UserModel();

        if (string_i_need.equals("Passenger")){
            holder.ll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i=new Intent(context, ContactUserActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    i.putExtra("sampleObject", mylist);
                    context.startActivity(i);
                }
            });
        }
        /*if (string_i_need.equals("Passenger")){
            holder.ll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i=new Intent(context, ContactMechanicActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    i.putExtra("sampleObject", mylist);
                    context.startActivity(i);
                }
            });
        }*/


    }

    @Override
    public int getItemCount() {

        int arr = 0;
        try {
            if (list.size() == 0) {
                arr = 0;
            } else {
                arr = list.size();
            }
        } catch (Exception e) {

        }

        return arr;

    }

    class MyHolder extends RecyclerView.ViewHolder {
        TextView textViewName, textViewLocation,textViewPhno,textViewDate;
        LinearLayout ll;


        public MyHolder(View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.textViewName);
            textViewPhno = itemView.findViewById(R.id.textViewPhno);
            textViewDate = itemView.findViewById(R.id.textViewDate);
            //textViewLocation = itemView.findViewById(R.id.textViewLocation);


            ll = itemView.findViewById(R.id.ll);
        }
    }
}
