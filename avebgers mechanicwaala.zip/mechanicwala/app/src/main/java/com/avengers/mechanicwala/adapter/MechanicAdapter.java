package com.avengers.mechanicwala.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.avengers.mechanicwala.ContactMechanicActivity;
import com.avengers.mechanicwala.DistanceCalculator;
import com.avengers.mechanicwala.GPS_Service;
import com.avengers.mechanicwala.R;
import com.avengers.mechanicwala.model.MechanicModel;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.annotations.NonNull;

public class MechanicAdapter extends RecyclerView.Adapter<MechanicAdapter.MyHolder> implements Filterable  {
    @NonNull
    private ArrayList<String> listS;
    List<MechanicModel> list;
    Context context;
    int minteger = 0;
    MyHolder holder;
    String string_i_need;

    public MechanicAdapter(List<MechanicModel> list, Context context,String string_i_need) {
        this.list = list;
        this.context = context;
        this.string_i_need=string_i_need;

    }

    public MechanicAdapter() {

    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.mechanic_item, parent, false);
        MyHolder myHoder = new MyHolder(view);
        StrictMode.ThreadPolicy st = new StrictMode.ThreadPolicy.Builder().build();
        StrictMode.setThreadPolicy(st);

        return myHoder;
    }

    @Override
    public void onBindViewHolder(final MyHolder holder, final int position) {
        final MechanicModel mylist = list.get(position);

        GPS_Service gps = new GPS_Service(context,"10");
        context.startService(new Intent(context,GPS_Service.class));

        double dist=0;
        if(gps.canGetLocation()) {
            double latitude = gps.getLatitude();
            double longitude = gps.getLongitude();
            dist= DistanceCalculator.calculateDistance(latitude,longitude,Double.parseDouble(mylist.getLocation().split(" ")[0]),Double.parseDouble(mylist.getLocation().split(" ")[1]));
        }

        holder.textViewDistance.setText("far away: "+dist+" km");
        holder.textViewName.setText("Name: "+mylist.getName());
        holder.textViewPhno.setText("Phone no: "+mylist.getPhno());
        holder.textViewProfession.setText("Profession: "+mylist.getProfession());
        holder.textViewDescription.setText("description: "+mylist.getDescription());
        holder.textViewAddress.setText("Address: "+mylist.getAddress());

        if (string_i_need.equals("Passenger")){
            holder.ll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i=new Intent(context, ContactMechanicActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    i.putExtra("sampleObject", mylist);
                    context.startActivity(i);
                }
            });
        }


    }

    @Override
    public int getItemCount() {

        int arr = 0;
        try {
            if (list.size() == 0) {
                arr = 0;
            } else {
                arr = list.size();
            }
        } catch (Exception e) {

        }

        return arr;

    }

    @Override
    public Filter getFilter() {
        return null;
    }

    class MyHolder extends RecyclerView.ViewHolder {
        TextView textViewName,textViewDistance,textViewBadge,textViewAddress,textViewDescription, textViewLocation,textViewPhno,textViewProfession,textViewkms,textViewfare,
                textViewinsurance,textViewDriverPhone,textViewDriverName,textViewDriverUpi;
        LinearLayout ll;


        public MyHolder(View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.textViewName);
            textViewPhno = itemView.findViewById(R.id.textViewPhno);
            textViewProfession = itemView.findViewById(R.id.textViewProfession);
            textViewAddress = itemView.findViewById(R.id.textViewAddress);
            textViewDistance=itemView.findViewById(R.id.distance);
            textViewDescription=itemView.findViewById(R.id.textViewDescription);
            textViewBadge=itemView.findViewById(R.id.textViewBadge);
            ll = itemView.findViewById(R.id.ll);
        }
    }
}
