package com.avengers.mechanicwala;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.avengers.mechanicwala.model.MechanicModel;
import com.avengers.mechanicwala.model.UserModel;
import com.avengers.mechanicwala.model.UserRequest;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class ContactUserActivity extends AppCompatActivity {
    TextView textViewName, textViewLocation,textViewPhno,textViewProfession;
    FirebaseStorage storage;
    StorageReference storageReference;

    List<UserModel> list=new ArrayList<>();
    List<String> mList=new ArrayList<>();
    DatabaseReference mDatabaseReferenceToAddData;
    ValueEventListener valueEventListener;
    DatabaseReference mDatabaseReference;
    private FirebaseUser mCurrentUser;
    FirebaseUser firebaseUser;
    String uid;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 1;
    private SmsManager sms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_user);

        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        uid=firebaseUser.getUid();

        mCurrentUser= FirebaseAuth.getInstance().getCurrentUser();
        storage = FirebaseStorage.getInstance();
        storageReference = FirebaseStorage.getInstance().getReference();
        mDatabaseReferenceToAddData = FirebaseDatabase.getInstance().getReference();
        mDatabaseReference=mDatabaseReferenceToAddData.child("users");

        StrictMode.ThreadPolicy st= new StrictMode.ThreadPolicy.Builder().build();
        StrictMode.setThreadPolicy(st);

        Intent i = getIntent();
        final UserRequest dene = (UserRequest) i.getSerializableExtra("sampleObject");

        textViewName = findViewById(R.id.textViewName);
        textViewPhno = findViewById(R.id.textViewPhno);
        Button navigate=findViewById(R.id.navigate);
        final WebView mapWebView=findViewById(R.id.map_web_view);
        navigate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(dene.getLocation()==null)
                {
                    Toast.makeText(getApplicationContext(),"the user currently unavailable to locate",Toast.LENGTH_SHORT).show();
                }
                else {
                    String url = "https://www.google.com/maps/search/?api=1&query=" + dene.getLocation().split(" ")[0] + "," +
                            dene.getLocation().split(" ")[1];
                    mapWebView.getSettings().setGeolocationEnabled(true);
                    mapWebView.getSettings().setJavaScriptEnabled(true);
                    mapWebView.setWebChromeClient(new WebChromeClient()
                    {
                        @Override
                        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                            callback.invoke(origin, true, false);
                        }
                    });
                    mapWebView.loadUrl(url);


                }
            }
        });

        if(dene.getUserName()!=null)
            textViewName.setText(dene.getUserName());
        if(dene.getUserPhno()!=null)
            textViewPhno.setText(dene.getUserPhno());

        final UserModel journeyModel=new UserModel();
        final UserRequest userRequest=new UserRequest();

        sms=SmsManager.getDefault();


        Button call_button=findViewById(R.id.call_button);
        Button message_button=findViewById(R.id.msg_button);
        call_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent phoneIntent = new Intent(Intent.ACTION_CALL);
                phoneIntent.setData(Uri.parse("tel:"+textViewPhno.getText().toString()));
                if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                        Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                startActivity(phoneIntent);
            }
        });
        message_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                        Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                sendSMSMessage(dene.getUserPhno().toString(),"sendind sms");
            }
        });
    }

    //messaging

    protected void sendSMSMessage(String phoneNo,String message) {

        LayoutInflater inflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        PopupWindow pw = new PopupWindow(inflater.inflate(R.layout.popup_window, null, false),400,400, true);

        pw.showAtLocation(this.findViewById(R.id.msg_button), Gravity.CENTER, 0, 0);
        final TextView phno=pw.getContentView().findViewById(R.id.phno);
        final EditText msgEditText=pw.getContentView().findViewById(R.id.msg);
        Button sendButton=pw.getContentView().findViewById(R.id.send);

        phno.setText(phoneNo);


        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String phnoo=phno.getText().toString();
                String mesage=msgEditText.getText().toString();
                sms.sendTextMessage(phnoo,null,mesage,null,null);

            }
        });


    }


}
