package com.avengers.mechanicwala;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.avengers.mechanicwala.adapter.MechanicAdapter;
import com.avengers.mechanicwala.adapter.UserAdapter;
import com.avengers.mechanicwala.model.MechanicModel;
import com.avengers.mechanicwala.model.UserModel;
import com.avengers.mechanicwala.model.UserRequest;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class MechanicHomeActivity extends AppCompatActivity {
    FirebaseStorage storage;
    StorageReference storageReference;

    List<UserRequest> list=new ArrayList<>();
    List<String> mList=new ArrayList<>();
    DatabaseReference mDatabaseReferenceToAddData;
    ValueEventListener valueEventListener;
    RecyclerView recyclerView;
    UserAdapter mAdapter;
    FirebaseUser firebaseUser;
    MechanicModel currentMechanic;
    DatabaseReference mDatabaseReference;
    DatabaseReference mDatabaseReferenceUsers;

    Spinner search;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mechanic_home);

        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        String uid=firebaseUser.getUid();
        recyclerView=findViewById(R.id.recy);

        Button logout=findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();

            }
        });

        currentMechanic=new MechanicModel();
        storage = FirebaseStorage.getInstance();
        storageReference = FirebaseStorage.getInstance().getReference();
        mDatabaseReferenceToAddData = FirebaseDatabase.getInstance().getReference();
        StrictMode.ThreadPolicy st= new StrictMode.ThreadPolicy.Builder().build();
        StrictMode.setThreadPolicy(st);


        mDatabaseReference=mDatabaseReferenceToAddData.child("mechanics");
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();
        mDatabaseReference.child(firebaseUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot==null)
                {
                    Log.d("datasnapshot","null");
                }
//               currentMechanic.setPhno(dataSnapshot.child("phno").getValue().toString());
                Toast.makeText(getApplicationContext(),"hello "+dataSnapshot.child("phno").toString(),Toast.LENGTH_SHORT).show();
                viewData(dataSnapshot.child("phno").getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });




    }



    private void viewData(String s) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference mDatabaseReference = database.getReference("Mechanic Wala").child("user request").child(s);

        valueEventListener=mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // if(dataSnapshot.exists()){
                for (DataSnapshot child : dataSnapshot.getChildren()) {

                    mList.add(child.getKey());
                    UserRequest message =child.getValue(UserRequest.class);
                    list.add(message);
                }
                mAdapter=new UserAdapter(list,getApplicationContext(),"Passenger");
                recyclerView.setAdapter(mAdapter);
                mAdapter.notifyDataSetChanged();
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 1));


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
