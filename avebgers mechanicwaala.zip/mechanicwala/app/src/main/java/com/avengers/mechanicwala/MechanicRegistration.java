package com.avengers.mechanicwala;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;

import java.util.HashMap;
import java.util.Map;

public class MechanicRegistration extends AppCompatActivity {

    ProgressDialog progressDialog;
    FirebaseAuth mauth;

    private DatabaseReference mDatabase;
    GPS_Service  gps;
    String check="Mechanic";
    private EditText inputEmail;
    private EditText inputPassword;
    private EditText inputPhno;
    private EditText inputName;
    private Spinner inputProfession;
    private String location;
    private  String email,password;

    private Button signUp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mechanic_registration);

       // auth = FirebaseAuth.getInstance();
        //

        GPS_Service gps = new GPS_Service(getApplicationContext(),"10");
        startService(new Intent(getApplicationContext(),GPS_Service.class));

        double dist=0;
        if(gps.canGetLocation()) {
            double latitude = gps.getLatitude();
            double longitude = gps.getLongitude();
            location=latitude+" "+longitude;
        }

signUp=findViewById(R.id.signUp);
signUp.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        inputEmail =findViewById(R.id.email);
        inputPassword=findViewById(R.id.password);
        inputName=findViewById(R.id.name);
        inputPhno=findViewById(R.id.phno);
        inputProfession=findViewById(R.id.profession);
      //  location=findViewById(R.id.location);

//
        Spinner spinner = (Spinner) findViewById(R.id.profession);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getApplicationContext(),R.array.mechanics_list, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);
        String s=spinner.getSelectedItem().toString();
        //
        email= inputEmail.getText().toString();
        password=inputPassword.getText().toString();
        //
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 6) {
            Toast.makeText(getApplicationContext(), "Password too short, enter minimum 6 characters!", Toast.LENGTH_SHORT).show();
            return;
        }
        //

        progressDialog=new ProgressDialog(MechanicRegistration.this);

        mauth=FirebaseAuth.getInstance();
        mDatabase= FirebaseDatabase.getInstance().getReference().child("mechanics");



        progressDialog.setMessage("Please wait while we are creating your account... ");
        progressDialog.setCancelable(false);
        progressDialog.setProgress(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();
        //create user
        register_user(inputName.getText().toString(),inputEmail.getText().toString(),inputPassword.getText().toString(),
                inputPhno.getText().toString(),inputProfession.getSelectedItem().toString(),location);
    }
});

    }
    private void register_user(final String displayname, String email, String password, final String phoneNumber, final String profession, final String location) {

        mauth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(this,new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                //------IF USER IS SUCCESSFULLY REGISTERED-----
                if(task.isSuccessful()){

                    FirebaseUser current_user = FirebaseAuth.getInstance().getCurrentUser();
                    final String uid=current_user.getUid();

                    String token_id = FirebaseInstanceId.getInstance().getToken();
                    Map userMap=new HashMap();
                    userMap.put("device_token",token_id);
                    userMap.put("name",displayname);
                    userMap.put("phno",phoneNumber);
                    userMap.put("status","Hello");
                    userMap.put("image","default");
                    userMap.put("thumb_image","default");
                    userMap.put("online","true");
                    userMap.put("user",check);
                    userMap.put("mechanic","mechanic");
                    userMap.put("profession",profession);
                    userMap.put("location",location);

                    DatabaseReference mDatabaseForProfession= FirebaseDatabase.getInstance().getReference().child("profession");
                   mDatabaseForProfession.child(profession).push().setValue(userMap);

                    mDatabase.child(uid).setValue(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task1) {
                            if(task1.isSuccessful()){

                                progressDialog.dismiss();
                                Toast.makeText(getApplicationContext(), "New User is created", Toast.LENGTH_SHORT).show();
                                Intent intent=new Intent(MechanicRegistration.this,MechanicLogin.class);
                                intent.putExtra("Strng_I_need",check);
                                //----REMOVING THE LOGIN ACTIVITY FROM THE QUEUE----
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                                finish();



                            }
                            else{

                                Toast.makeText(MechanicRegistration.this, "YOUR NAME IS NOT REGISTERED... MAKE NEW ACCOUNT-- ", Toast.LENGTH_SHORT).show();

                            }

                        }
                    });


                }
                //---ERROR IN ACCOUNT CREATING OF NEW USER---
                else{
                    progressDialog.dismiss();
                    Toast.makeText(getApplicationContext(), "ERROR REGISTERING USER....", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


}
