package com.avengers.mechanicwala.model;

import java.io.Serializable;

public class UserRequest implements Serializable {

    String userName;
    String UserPhno;
    String date;

    String location;
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }




    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPhno() {
        return UserPhno;
    }

    public void setUserPhno(String userPhno) {
        UserPhno = userPhno;
    }




    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
