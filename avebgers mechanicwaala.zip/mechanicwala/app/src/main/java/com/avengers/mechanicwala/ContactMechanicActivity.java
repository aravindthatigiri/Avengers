package com.avengers.mechanicwala;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.avengers.mechanicwala.model.MechanicModel;
import com.avengers.mechanicwala.model.UserModel;
import com.avengers.mechanicwala.model.UserRequest;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class ContactMechanicActivity extends AppCompatActivity {
    TextView textViewName, textViewLocation,textViewPhno,textViewProfession;
    FirebaseStorage storage;
    StorageReference storageReference;

    List<UserModel> list=new ArrayList<>();
    List<String> mList=new ArrayList<>();
    DatabaseReference mDatabaseReferenceToAddData;
    ValueEventListener valueEventListener;
    DatabaseReference mDatabaseReference;
    private FirebaseUser mCurrentUser;
    FirebaseUser firebaseUser;
    String currentLocation="0.0 0.0";
    String uid;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 1;
    private SmsManager sms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_mechanic);

        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        uid=firebaseUser.getUid();


        //location
        GPS_Service gps=new GPS_Service(getApplicationContext(),"10");
        startService(new Intent(getApplicationContext(),GPS_Service.class));
        if(gps.canGetLocation())
        {
            currentLocation=gps.getLatitude()+" "+gps.getLongitude();
        }
        //
        mCurrentUser= FirebaseAuth.getInstance().getCurrentUser();
        storage = FirebaseStorage.getInstance();
        storageReference = FirebaseStorage.getInstance().getReference();
        mDatabaseReferenceToAddData = FirebaseDatabase.getInstance().getReference();
        mDatabaseReference=mDatabaseReferenceToAddData.child("users");

        StrictMode.ThreadPolicy st= new StrictMode.ThreadPolicy.Builder().build();
        StrictMode.setThreadPolicy(st);

        Intent i = getIntent();
        final MechanicModel dene = (MechanicModel)i.getSerializableExtra("sampleObject");

        textViewName = findViewById(R.id.textViewName);
        textViewPhno = findViewById(R.id.textViewPhno);
        textViewProfession = findViewById(R.id.textViewProfession);
       // textViewLocation = findViewById(R.id.textViewLocation);

        if(dene.getName()!=null)
        textViewName.setText(dene.getName());
        if(dene.getPhno()!=null)
        textViewPhno.setText(dene.getPhno());
        if(dene.getProfession()!=null)
        textViewProfession.setText(dene.getProfession());
        final UserModel journeyModel=new UserModel();
        final UserRequest userRequest=new UserRequest();

        sms=SmsManager.getDefault();
        findViewById(R.id.contact_mechanic).setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {

//                Toast.makeText(getApplicationContext(),mDatabaseReference.child(mCurrentUser.getUid()).getKey(),Toast.LENGTH_SHORT).show();
               // journeyModel.setName();
                //journeyModel.setPhno("");
               // journeyModel.setLocation("");

                //



                //
                Date c = Calendar.getInstance().getTime();
                System.out.println("Current time => " + c);

                SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                String formattedDate = df.format(c);
                userRequest.setDate(formattedDate);
                mDatabaseReferenceToAddData.child("Mechanic Wala").child("user request").child(dene.getPhno()).push().setValue(userRequest);




            }
        });
        mDatabaseReference.child(mCurrentUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                userRequest.setUserName(dataSnapshot.child("name").getValue().toString());
                userRequest.setUserPhno(dataSnapshot.child("phno").getValue().toString());
                userRequest.setLocation(currentLocation);
                userRequest.setDate("not set");
               // journeyModel.setLocation(dataSnapshot.child("location").getValue().toString());

                Toast.makeText(getApplicationContext(),"userr"+dataSnapshot.child("name").getValue().toString(),Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        Button call_button=findViewById(R.id.call_button);
        Button message_button=findViewById(R.id.msg_button);
        call_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent phoneIntent = new Intent(Intent.ACTION_CALL);
                phoneIntent.setData(Uri.parse("tel:"+textViewPhno.getText().toString()));
                if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                        Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                  return;
                }
                startActivity(phoneIntent);
            }
        });
        message_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                        Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                sendSMSMessage(dene.getPhno().toString(),"sendind sms");
            }
        });
    }

    //messaging

    protected void sendSMSMessage(String phoneNo,String message) {

        LayoutInflater inflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        PopupWindow pw = new PopupWindow(inflater.inflate(R.layout.popup_window, null, false),400,400, true);

        pw.showAtLocation(this.findViewById(R.id.msg_button), Gravity.CENTER, 0, 0);
        final TextView phno=pw.getContentView().findViewById(R.id.phno);
        final EditText msgEditText=pw.getContentView().findViewById(R.id.msg);
        Button sendButton=pw.getContentView().findViewById(R.id.send);

        phno.setText(phoneNo);


        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String phnoo=phno.getText().toString();
                String mesage=msgEditText.getText().toString();
                sms.sendTextMessage(phnoo,null,mesage,null,null);

            }
        });


    }


}
