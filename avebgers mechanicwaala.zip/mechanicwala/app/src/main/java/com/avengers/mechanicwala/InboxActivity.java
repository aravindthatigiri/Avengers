package com.avengers.mechanicwala;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.avengers.mechanicwala.R;
import com.avengers.mechanicwala.adapter.MechanicAdapter;
import com.avengers.mechanicwala.model.MechanicModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class InboxActivity extends AppCompatActivity {

    FirebaseStorage storage;
    StorageReference storageReference;

    List<MechanicModel> list=new ArrayList<>();
    List<String> mList=new ArrayList<>();
    DatabaseReference mDatabaseReferenceToAddData;

    ValueEventListener valueEventListener;
    RecyclerView recyclerView;
    MechanicAdapter mAdapter;

    String currentLocation="";
    FirebaseDatabase database ;
    DatabaseReference mDatabaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_search);



        database = FirebaseDatabase.getInstance();
         mDatabaseReference = database.getReference("mechanics");

        final Spinner search_spinner=findViewById(R.id.search_spinner);
        Button search=findViewById(R.id.search_button);

        //forlocation

        GPS_Service gps = new GPS_Service(getApplicationContext(),"10");
        startService(new Intent(getApplicationContext(),GPS_Service.class));

        double dist=0;
        if(gps.canGetLocation()) {
            double latitude = gps.getLatitude();
            double longitude = gps.getLongitude();
            currentLocation+=latitude+" "+longitude;
        }

        Button logout=findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDatabaseReference=database.getReference("profession");
                viewData(mDatabaseReference.child(search_spinner.getSelectedItem().toString()));
            }
        });
        recyclerView=findViewById(R.id.recy);

        storage = FirebaseStorage.getInstance();

        storageReference = FirebaseStorage.getInstance().getReference();
        mDatabaseReferenceToAddData = FirebaseDatabase.getInstance().getReference();


        StrictMode.ThreadPolicy st= new StrictMode.ThreadPolicy.Builder().build();
        StrictMode.setThreadPolicy(st);
        viewData(mDatabaseReference);
    }



    private void viewData(DatabaseReference mDatabaseReference) {

        mList=new ArrayList<>();
        list=new ArrayList<>();

        valueEventListener=mDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // if(dataSnapshot.exists()){
                for (DataSnapshot child : dataSnapshot.getChildren()) {

                    mList.add(child.getKey());
                    MechanicModel message =child.getValue(MechanicModel.class);
                    list.add(message);
                }

                //sorting based on location
                    for(int i=0;i<list.size();i++)
                    {
                        for(int j=i+1;j<list.size();j++) {
                            Double distanceToI = DistanceCalculator.calculateDistance(Double.parseDouble(currentLocation.split(" ")[0]), Double.parseDouble(currentLocation.split(" ")[1]),
                                    Double.parseDouble(list.get(i).getLocation().split(" ")[0]), Double.parseDouble(list.get(i).getLocation().split(" ")[1]));
                            Double distanceToJ = DistanceCalculator.calculateDistance(Double.parseDouble(currentLocation.split(" ")[0]), Double.parseDouble(currentLocation.split(" ")[1]),
                                    Double.parseDouble(list.get(j).getLocation().split(" ")[0]), Double.parseDouble(list.get(j).getLocation().split(" ")[1]));
                            if (distanceToI >distanceToJ)
                            {
                                MechanicModel temp=list.get(i);
                                list.set(i,list.get(j));
                                list.set(j,temp);
                            }
                        }
                    }

                //
                mAdapter=new MechanicAdapter(list,getApplicationContext(),"Passenger");
                recyclerView.setAdapter(mAdapter);
                mAdapter.notifyDataSetChanged();
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 1));


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
